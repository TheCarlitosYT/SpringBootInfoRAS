package com.example.InfoRAS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfoRasApplicationTests {

	@Test
	void contextLoads() {
	}

}
